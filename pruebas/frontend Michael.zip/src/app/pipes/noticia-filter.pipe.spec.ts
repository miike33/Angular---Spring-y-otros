import { NoticiaFilterPipe } from './noticia-filter.pipe';

describe('NoticiaFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new NoticiaFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
