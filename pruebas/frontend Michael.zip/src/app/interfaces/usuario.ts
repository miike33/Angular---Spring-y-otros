export interface Usuario {
    nombre: string;
    email: string;
    password: string;
    id_user?: number;
}
