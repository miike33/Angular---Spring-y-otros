package com.mike.backend.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EoiWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
