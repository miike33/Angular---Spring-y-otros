<?php

header("Access-Control-Allow-Origin: *");

file_put_contents("tareas.txt",$_GET[tarea]."\n",FILE_APPEND);

echo json_encode(file("tareas.txt"));

?>