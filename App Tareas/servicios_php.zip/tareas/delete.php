<?php

header("Access-Control-Allow-Origin: *");

unlink("tareas.txt");

?>