<?php

header("Access-Control-Allow-Origin: *");

echo json_encode(file("tareas.txt"));

?>