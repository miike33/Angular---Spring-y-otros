import { CategoriaFilterPipe } from './categoria-filter.pipe';

describe('CategoriaFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CategoriaFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
